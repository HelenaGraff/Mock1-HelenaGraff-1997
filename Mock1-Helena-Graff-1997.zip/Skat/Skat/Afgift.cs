﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skat
{
    public class Afgift
    {
        
        public int BilAfgift(int pris)
        {
            double bilAfgift;

            //Da metoden ikke må kaldes med en negativ pris, tjekkes der for om prisen er negativ
            //Hvis prisen er mindre end 0, vil der derfor blive kastet en exception
            if (pris < 0)
            {
                throw new ArgumentException("Pris må ikke være mindre end eller lig med 0");
            }

            //Hvis prisen er mindre end eller lig med 200000 bruges formlen: bilAfgift = pris*0,85
            if (pris <= 200000)
            {
                bilAfgift = pris * 0.85;
            }
            //Hvis prisen er større end 200000 bruges formlen: bilafgift = (pris*0,15)-130000
            else
            {
                bilAfgift = (pris * 1.5) - 130000;
            }

            //Her konverterer jeg double bilafgift til en int afgift, da metoden skal returnerer en int
            int afgift = Convert.ToInt32(bilAfgift);

            //Her returneres afgiften på en given bil
            return afgift;
        }


        public int ElBilAfgift(int pris)
        {
            double elBilAfgift;

            //Da metoden ikke må kaldes med en negativ pris, tjekkes der for om prisen er negativ
            //Hvis prisen er mindre end 0, vil der derfor blive kastet en exception
            if (pris < 0)
            {
                throw new ArgumentException("Pris må ikke være mindre end eller lig med 0");
            }


            //Da man som ejer af en elbil kun skal betale 20% af en almindelig personbilsafgift skal man først udregne personbilsafgiften
            //hvorfor man bruger formlen: hvis bilens pris er mindre end eller lig med 200000: elbilAfgift = pris*0,85
            //når man så har udregnet afgiften af en personbil skal man begregne 20% af denne pris
            if (pris <= 200000)
            {
                elBilAfgift = pris * 0.85;
                elBilAfgift = elBilAfgift * 0.20;
            }
            //Hvis prisen er større end 200000 bruges formlen: bilafgift = (pris*0,15)-130000
            else
            {
                elBilAfgift = (pris * 1.5) - 130000;
                elBilAfgift = elBilAfgift * 0.20;
            }

            //Her konverterer jeg double elbilafgift til en int afgift, da metoden skal returnerer en int
            int afgift = Convert.ToInt32(elBilAfgift);

            //Her returneres afgiften på en given bil
            return afgift;
        }
    }
}
