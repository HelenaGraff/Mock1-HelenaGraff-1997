﻿using System;
using System.IO;
using System.Net.Sockets;

namespace TCPSkatClient
{
    class TcpSkatClient
    {
        static void Main(string[] args)
        {
            TcpClient connectionSocket = new TcpClient("127.0.0.1", 7000);
            Console.WriteLine("Klienten er klar");
            
            Stream ns = connectionSocket.GetStream();
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);
            sw.AutoFlush = true;

            Console.WriteLine("Indtast bil eller elbil");
            while (true)
            {
                string message = Console.ReadLine();
                sw.WriteLine(message);

                if (message == "Stop" || message == "stop") break;

                string answer = sr.ReadLine();
                Console.WriteLine("Server: " + answer);
            }

            Console.WriteLine("Tak for denne gang. Tryk enter for at lukke vinduet");
            Console.ReadKey();

            ns.Close();
            connectionSocket.Close();
        }
    }
}
